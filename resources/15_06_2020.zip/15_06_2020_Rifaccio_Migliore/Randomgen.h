#ifndef __RandomGen_h__
#define __RandomGen_h__

#include <iostream>
#include <cmath>


class RandomGen{

  public:

    RandomGen(unsigned int);

    void SetA(unsigned int a){ m_a = a; };
    void SetC(unsigned int c){ m_c = c; };
    void SetM(unsigned int m){ m_m = m; };
    void SetSeed(unsigned int seed){ m_seed = seed; };

    unsigned int GetA(){ return m_a; };
    unsigned int GetC(){ return m_c; };
    unsigned int GetM(){ return m_m; };
    unsigned int GetSeed(){ return m_seed; };


    double Random();
    double Uniform(double, double);
    double Exponential(double);
    double Gauss(double, double);
    double GaussAr(double, double);


  private:
    int m_seed;
    unsigned int m_a, m_c, m_m;

};















#endif
