#ifndef __Funzione_Base_h__
#define __Funzione_Base_h__

#include <iostream>
#include <cmath>

using namespace std;

class FunzioneBase{

  public:

    virtual double Eval(double x) const = 0 ; //Sto creando un metodo Eval che è generale. Ogni classe derivata dovra avere un metdo eval

};


class Funzione : public FunzioneBase{

  public:

    Funzione();
    ~Funzione();

    virtual double Eval(double) const ;

};

class Funzione1 : public FunzioneBase{

  public:

    Funzione1();
    ~Funzione1();

    virtual double Eval(double) const ;

};

#endif
