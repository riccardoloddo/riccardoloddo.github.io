#include "Integrali.h"

MidPoint::MidPoint(double xmin, double xmax, int passi){ //L'esercizio dice con un numero di passi fissato quindi nel costruttore
                                                         //faccio prendere il numero di passi
  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
  m_passi = passi;
};

MidPoint::~MidPoint(){ ; };

double MidPoint::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 2;

  do {
    integral = 0;
    half_integral = 0;
    h = (m_b - m_a)/double(i);
    for(int p = 0; p < i; p++){
      integral += f->Eval(m_a + (p + 0.5)*h)*h;
    }
    for(int p = 0; p < i*2; p++){ //devo metterci *2 poichè h e dimezzato quindi il numero di passi  doppio, devo sommare il doppio delle cose.
      half_integral += f->Eval(m_a + (p + 0.5)*h*0.5)*(h*0.5);
    }
    i *= 2;
  }while((4./3.)*fabs(half_integral - integral) > prec);

  return integral;

};



double MidPoint::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = 0;

  for(int p = 0; p < m_passi; p++)
    integral += f->Eval(m_a + (p + 0.5)*h);

  return integral*h;

};

MidRight::MidRight(double xmin, double xmax ){

  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
};

MidRight::~MidRight(){ ; };

double MidRight::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 2;

  do {
    integral = 0;
    half_integral = 0;
    h = (m_b - m_a)/double(i);
    for(int p = 0; p < i; p++){
      integral += f->Eval(m_a + (p + 0.5)*h)*h;
    }
    for(int p = 0; p < i*2; p++){ //devo metterci *2 poichè h e dimezzato quindi il numero di passi  doppio, devo sommare il doppio delle cose.
      half_integral += f->Eval(m_a + (p + 0.5)*h*0.5)*(h*0.5);
    }
    i *= 2;
  }while((4./3.)*fabs(half_integral - integral) > prec);

  return integral;

};


double MidRight::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = 0;

  for(int p = 0; p < m_passi; p++)
    integral += f->Eval(m_a + (p + 1)*h);

  return integral*h;

};

Simpson::Simpson(double xmin, double xmax, int passi){ //L'esercizio dice con un numero di passi fissato quindi nel costruttore
                                                         //faccio prendere il numero di passi
  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
  m_passi = passi;
};

Simpson::~Simpson(){ ; };

double Simpson::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 2;

  do {
    integral = f->Eval(m_a) + f->Eval(m_b);
    half_integral = f->Eval(m_a) + f->Eval(m_b);
    h = (m_b - m_a)/double(i);
    for(int p = 1; p < i; p += 2){
      integral += 4*f->Eval(m_a + p*h) + 2*f->Eval(m_a + (p+1)*h);
    }
    for(int p = 1; p < i*2; p += 2){
      half_integral += 4*f->Eval(m_a + p*h*0.5) + 2*f->Eval(m_a + (p+1)*h*0.5);
    }
    i *=2;
  }while((16./15.)*fabs(integral*h - half_integral*h*0.5) > prec);

  return integral*h/double(3);

};

/*
double Integrale::Simpson(int n, double precision){

    int p{1};
    double m_int_prec;
    m_h = (m_b-m_a);
    m_sum =  (m_f->Eval(m_a, n))+(m_f->Eval(m_b, n));

    do {
      m_int_prec = m_sign*m_sum*m_h*(1./6.);

      p = p << 1 ;

      m_h = m_h/2.;

      for(unsigned int i=1; i<=(p/2); i+=2){
        m_sum += 4*(m_f->Eval(m_a + i*m_h, n))+2*(m_f->Eval(m_a + (i+1)*m_h, n));
      }
      m_integrale = m_sign*m_sum*m_h*(1./6.);

    } while ((4./3.)*fabs( m_integrale - m_int_prec) > precision);


  return m_integrale;
}
*/

double Simpson::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = f->Eval(m_a) + f->Eval(m_b);

  for(int p = 1; p < m_passi; p += 2)
    integral += 4*f->Eval(m_a + p*h) + 2*f->Eval(m_a + (p+1)*h);

  return integral*h/double(3);

};


Trapezi::Trapezi(double xmin, double xmax, int passi){ //L'esercizio dice con un numero di passi fissato quindi nel costruttore
                                                         //faccio prendere il numero di passi
  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
  m_passi = passi;
};

Trapezi::~Trapezi(){ ; };

double Trapezi::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 1;

  do {
    integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;
    half_integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;
    h = (m_b - m_a)/double(i);
    for(int p = 1; p < i; p++){
      integral += f->Eval(m_a + p*h) ;
      //cout<<"integral: "<<integral<<endl;
    }
    for(int p = 1; p < i*2; p++){
      half_integral += f->Eval(m_a + p*h*0.5);
      //cout<<"half_integral: "<<half_integral<<endl;
    }
    i *= 2;
    }while((4./3.)*(fabs(integral*h - half_integral*h*0.5)) > prec);

  return integral*h;

};

double Trapezi::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;

  for(int p = 1; p < m_passi; p ++)
    integral += f->Eval(m_a + p*h) ;

  return integral*h;

};

/*double Trapezi::Integrale(const FunzioneBase* f) const { TRAPEZZI MIGLIORATOOOO!! SCALA COME H^4 SEMPLICIEMMTE FACENDO COSI!

  double h = (m_b - m_a)/m_passi;
  double integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;
  double half_integral = 0;

  for(int p = 1; p < m_passi; p ++)
    integral += f->Eval(m_a + p*h) ;

  for(int p = 1; p < m_passi*2; p++)
    half_integral += f->Eval(m_a + p*h*0.5);

  return (1./3.)*(4*half_integral*h*0.5 - integral*h);

};*/


/*double Trapezi::Metodo(const FunzioneBase* f){ //Anno scorso

  m_sum = 0;
  int i = 1;

  m_h = (m_b-m_a);
  m_sum  = (f->Eval(m_a) + f->Eval(m_b))/2.;


do{

  m_integral = m_sum*m_h*m_sign; //ad ogni ciclo mi salvo l'ultimo integrale
  i *= 2; //numero di passi
  m_h = (m_b-m_a)/i; //ogni volta dimezzo il passo

  for(int k=1; k<i-1; k+=2){
    m_sum += f->Eval(k*m_h); //prendo solo la f(h) con quell'h che sta in mezzo all'intervallo diviso..quindi ogni 2
  }

  m_integral_1 = m_sum*m_h*m_sign; //integrale usccessivo


}while((4./3.)*fabs(m_integral_1 - m_integral) > m_prec ); //controllo

return m_integral_1;

}*/

//ATTENZIONE: HO DUE DOMANDE: 1) GLI ALGORITMI VANNO BENE (CREDO) PERO MI SA CHE half_integral PUÒ ESSERE DIRETTAMENTE CALCOLATO DA INTEGRAL;
//IN QUESTO MODO L'ALGORITMO È PIÙ EFFICENTE.
//LA SECONDA DOMANDA MENO IMPORTANTE È SE i++ È GIUSTO. NON DOVREI SEMPRE DIMEZZARE IL PASSSO? NEGLI ALTRI ES DELL ANNO SCORSO HO MESSO i *= 2.

//RICORDARSI ANCHE IL TF1 PERCHE VIENE COSI E CAPIRE SE E COME È POSSIBILE RICAVARE K1 (costante che moltiplica l'errore)
