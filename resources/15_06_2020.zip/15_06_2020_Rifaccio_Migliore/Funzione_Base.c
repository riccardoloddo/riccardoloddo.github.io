#include "Funzione_Base.h"

Funzione::Funzione(){}

Funzione::~Funzione(){};


double Funzione::Eval(double x) const {
  return x*x*x*log( sqrt(exp(1)+x*x) );
};

Funzione1::Funzione1(){}

Funzione1::~Funzione1(){};


double Funzione1::Eval(double x) const {
  return pow( sqrt(4 - x*x), -1 );
};
