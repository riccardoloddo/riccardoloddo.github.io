#ifndef __Integrali_h__
#define __Integrali_h__

#include "Funzione_Base.h"

class Integral{

  public:

    virtual double Integrale(const FunzioneBase*, double) const = 0 ; //Sto creando un metodo Eval che è generale. Ogni classe derivata dovra avere un metdo eval

};

class MidPoint : public Integral {

  public:

    MidPoint(double, double, int);
    ~MidPoint();

    void SetPass(double passi) {m_passi = passi; };
    void SetA(double a) {m_a = a; };
    void SetB(double b) {m_b = b; };
    virtual double Integrale(const FunzioneBase*, double) const ;
    double Integrale(const FunzioneBase*) const ;



  private:
    double m_a, m_b; //Intervallo
    int m_passi;

};

class MidRight : public Integral {

  public:

    MidRight(double, double);
    ~MidRight();

    void SetPass(double passi) {m_passi = passi; };
    void SetA(double a) {m_a = a; };
    void SetB(double b) {m_b = b; };
    virtual double Integrale(const FunzioneBase*, double) const ;
    double Integrale(const FunzioneBase*) const ;



  private:
    double m_a, m_b; //Intervallo
    int m_passi;

};

class Simpson : public Integral{

  public:

    Simpson(double, double, int);
    ~Simpson();

    void SetPass(double passi) {m_passi = passi; };
    virtual double Integrale(const FunzioneBase*, double) const ;
    double Integrale(const FunzioneBase*) const ;

  private:
    double m_a, m_b; //Intervallo
    int m_passi;

};

class Trapezi : public Integral{

  public:

    Trapezi(double, double, int);
    ~Trapezi();

    void SetPass(double passi) {m_passi = passi; };
    virtual double Integrale(const FunzioneBase*, double) const ;
    double Integrale(const FunzioneBase*) const ;

  private:
    double m_a, m_b; //Intervallo
    int m_passi;

};



#endif
