#include "Integrali.h"
#include "TCanvas.h"
#include "TApplication.h"
#include "TGraph.h"
#include "TAxis.h"
#include "TF1.h"
#include <iomanip>
#include "TLegend.h"
#include "Montecarlo.h"
#include "TH1F.h"


using namespace std;

int main() {

  TApplication app("App", 0, 0); //Crea un ambiente applicativo

  TGraph* mygraph = new TGraph();
  TGraph* mygraph1 = new TGraph();
  TGraph* mygraph2 = new TGraph();
  TH1F *isto = new TH1F("Isto","Grafico_Integrale_Media",100, 0, 3 );
  FunzioneBase* Func = new Funzione();
  FunzioneBase* Func1 = new Funzione1();
  MidPoint* integral_m = new MidPoint(0, sqrt(exp(1)), 1000 );
  MidRight* integral_r = new MidRight( 0, sqrt(exp(1)) );
  Media* med = new Media( 0, sqrt(exp(1)) );

  integral_r->SetPass(1000.);

  for(int i = 1; i<11; i++){
    integral_m->SetPass(pow(2, i));
    integral_r->SetPass(pow(2, i));
    mygraph->SetPoint(i-1, pow(2, i), fabs ( (3./16.)*exp(2) - integral_m->Integrale( Func )   ) );
    mygraph1->SetPoint(i-1, pow(2, i), fabs ( (3./16.)*exp(2) - integral_r->Integrale( Func )   ) );
  }

  for(int i = 0; i<1000; i++){
    isto->Fill( med->Integral(Func, 16) );
  }

  TCanvas *mycanvas = new TCanvas();
  mycanvas->Divide(2, 1);
  mycanvas->cd(1);
  mycanvas->cd(1)->SetLogx();
  mycanvas->cd(1)->SetLogy();
  mygraph->SetTitle("Grafico_Errore_Integrale ");
  mygraph->GetXaxis()->SetTitle(" N ");
  mygraph->GetYaxis()->SetTitle(" Errore_Integrale ");
  mygraph->SetLineColor(4);
  mygraph1->SetLineColor(3);
  mygraph->SetMarkerStyle(20);
  mygraph1->SetMarkerStyle(20);
  mygraph->GetYaxis()->SetRangeUser(10E-8, 10);
  mygraph->Draw("ALP");
  mygraph1->Draw("sameLP");
  TLegend *mylegend = new TLegend(0.2,0.6,0.4,0.8);
  mylegend->AddEntry(mygraph,"This is MidPoint","LP");
  mylegend->AddEntry(mygraph1,"This is MidRight","LP");
  mylegend->Draw();
  mycanvas->cd(2);
  isto->GetXaxis()->SetTitle(" Value_Integral ");
  isto->GetYaxis()->SetTitle(" Frequenza ");
  isto->Draw();
  TF1* fitcampo = new TF1("fitcampo", "[0]*pow(x,[1])", 10E-7, 1024);
  mygraph->Fit(fitcampo);
  TF1* fitcampo1 = new TF1("fitcampo1", "[0]*pow(x,[1])", 10E-7, 1024);
  mygraph1->Fit(fitcampo1);

  cout<<endl<<"L integrale con il metodo MidPoint con passo N = 1000 è: "<<integral_m->Integrale( Func )<<endl;
  cout<<endl<<"L integrale con il metodo MidRight con passo N = 1000 è: "<<integral_r->Integrale( Func )<<endl;
  cout<<endl<<endl<<"Caso_MidPoint: "<<endl;
  cout<<"Assumendo che l'errore scalicome k1*h^k2 i valori di k1 e k2 sono rispettivamente: "<<endl<<endl;
  cout<<"k1: "<<fitcampo->GetParameter(0)<<"      k2: "<<fitcampo->GetParameter(1)<<endl;
  cout<<endl<<"Mi aspetto che k2 sia ragionevolmente vicino a 2 poichè MidPoint scala come h^2."<<endl;
  cout<<"OSS: Il risultato è con k2 negativo...circa -2 ma dal grafico sembrerebbe un +2. È perchè ho fatto il modulo."<<endl;
  cout<<endl<<endl<<"Caso_MidRight: "<<endl;
  cout<<"Assumendo che l'errore scalicome k1*h^k2 i valori di k1 e k2 sono rispettivamente: "<<endl<<endl;
  cout<<"k1: "<<fitcampo1->GetParameter(0)<<"      k2: "<<fitcampo1->GetParameter(1)<<endl;
  cout<<endl<<"Con il metodo della media l'integrale è: "<<isto->GetMean()<<" +/- "<<isto->GetRMS()<<endl;
  cout<<endl<<endl<<"ORA CALCOLO QUANTI PUNTI SAREBBERO NECESSARI CON IL METODO DELA MEDIA PER OTTENERE UNA PRECISIONE COME UELLA DI MIDPOINT CON PASSO 16."<<endl;
  cout<<"Sapendo che la media scala come err = k/sqrt(N) posso trovare k come k = err*sqrt(N). "<<endl;
  double k = isto->GetRMS()*sqrt(16);
  cout<<"La costante k è: "<<k<<endl;
  cout<<"Ora calocolo l'integrale con MidPoint a 16 punti e vedo l'errore commesso rispetto a quello vero. Questo errore sarà il nuovo err. "<<endl;
  integral_m->SetPass(16);
  double err = fabs ( (3./16.)*exp(2) - integral_m->Integrale( Func ) );
  cout<<"L'errore dell'integrale calcolato con il metodo MidPoint a 16 punti rispetto a il valore vero è: "<<err<<endl;
  cout<<"Il Numero di passi stimato è dato dunque dalla relazione N = (k/err)^2 . Quindi N = "<<pow( (k/err), 2 )<<endl;
  cout<<endl<<endl<<"CAMBIO_FUNZIONE"<<endl;
  integral_m->SetPass(1000);
  integral_m->SetA(0);
  integral_m->SetA(2);
  cout<<"L'integrale con il metodo MidPoint con N = 1000 è: "<<integral_m->Integrale( Func1 )<<endl;
  integral_r->SetPass(1000);
  integral_r->SetA(0);
  integral_r->SetA(2);
  cout<<"L'integrale con il metodo MidRight con N = 1000 è: "<<integral_r->Integrale( Func1 )<<endl;
  cout<<"Lavorando sull'estremo destro MidRight assume anche il valore 2, e quindi non va bene perchè l'integrale esplode all'infinito."<<endl;
  cout<<"In linea di massima il coefficente k2 rimane invariato..può cambiare ma è solo in base al metodo e all'estrazione di punti."<<endl;




/*
  TCanvas *mycanvas1 = new TCanvas();
  mycanvas1->cd();
  mycanvas1->SetGrid(1,1);
  mycanvas1->SetLogy();
  mycanvas1->SetLogx();
  mygraph1->SetTitle("Grafico Errore in funzione del numero di passi N");
  mygraph1->GetXaxis()->SetTitle(" N ");
  mygraph1->GetYaxis()->SetTitle(" Errore(N) ");
  mygraph1->SetLineColor(5);
  mygraph1->SetMarkerStyle(20);
  mygraph1->Draw("ALP");

  TCanvas *mycanvas2 = new TCanvas();
  mycanvas2->cd();
  mycanvas2->SetGrid(1,1);
  mycanvas2->SetLogy();
  mycanvas2->SetLogx();
  mygraph2->SetTitle("Grafico Errore in funzione della lunghezza del passo h");
  mygraph2->GetXaxis()->SetTitle(" h ");
  mygraph2->GetYaxis()->SetTitle(" Errore(h) ");
  mygraph2->SetLineColor(8);
  mygraph2->SetMarkerStyle(20);
  mygraph3->SetLineColor(5);
  mygraph3->SetMarkerStyle(20);
  mygraph2->GetXaxis()->SetRangeUser(10E-6, 1); //FONDAMENTALI. PER DECIDERE IL RANG ASSE X VA DA 10^-6 FINO AD 0.1
  mygraph2->GetYaxis()->SetRangeUser(10E-16, 50);
  mygraph2->Draw("ALP"); //per costruirli nello stesso grafico devo mettere same
  mygraph3->Draw("sameLP"); //per costruirli nello stesso grafico devo mettere same

  TLegend *mylegend = new TLegend(0.2,0.6,0.4,0.8);
  mylegend->AddEntry(mygraph2,"This is Trapezi","LP");
  mylegend->AddEntry(mygraph3,"This is Simpson","LP");
  mylegend->Draw();

  TF1* fitcampo0 = new TF1("fitcampo", "[0]*pow(x,[1])", 10E-7, 1);
  fitcampo0->SetParameter((4./3.)*(atof(argv[2])), 2);
  mygraph2->Fit(fitcampo0);


  TF1* fitcampo = new TF1("fitcampo", "[0]*pow(x,[1])", 10E-7, 1);
  fitcampo->SetParameter((16./15.)*(atof(argv[2])), 4);
  mygraph3->Fit(fitcampo);



  cout<<"Come si puo vedere dai grafici l'errore scala con h al quadrato. Infatti spostandoci da h = 1 a h = 0.1 l'errore ha subito 2 ordini di grandezza ";
  cout<<"in meno. Si puo anche osservare come più h e piccolo (o analogamente piu N è grande) verso la fine si vede che il grafico subisce una strana inclinazione: ";
  cout<<"esso potrebbe essere dovuto all'errore di rounding, ovvero l'errore dominante non è più quello del metodo ma sono gli errori di arrotondamento"<<endl;
*/

  app.Run();



  return 0;

}
