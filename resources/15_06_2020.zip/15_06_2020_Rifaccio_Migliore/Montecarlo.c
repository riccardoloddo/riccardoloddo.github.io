#include "Montecarlo.h"

Media::Media(double a, double b) : RandomGen(1.){

  m_a = a;
  m_b = b;
};

double Media::Integral(FunzioneBase* f, int N){

  double x;
  double sum_f = 0;
  for(int i = 0; i<N; i++){
    x = Uniform(GetA(), GetB());
    sum_f += f->Eval(x);
  }
  return (  GetB() - GetA() )*sum_f/double(N);

};

HitorMiss::HitorMiss(double a, double b, double max) : RandomGen(1.){

  m_a = a;
  m_b = b;
  m_max = max;
};

double HitorMiss::Integral(FunzioneBase* f, int N){

  double x;
  double y;
  double Ntot = 0;
  double Nhit = 0;


  do{
    x = Uniform( GetA(), GetB() );
    y = Uniform( 0., GetMax() );
    Ntot++;
    if( y < f->Eval(x) )
      Nhit++;
  }while(Ntot < N);

  return (  GetB() - GetA() )*GetMax()*double(Nhit)/double(Ntot);

};
