// Simple ROOT macro to plot a histogram.
// Modify arguments as needed.
// To execute, type .X plotUni.C
{
  TFile* f = new TFile("simpleMC.root");
  f->ls();
  TH1D* h1 = (TH1D*)f->Get("h_Uni1");
  TH1D* h2 = (TH1D*)f->Get("h_Uni2");
  TH1D* h3 = (TH1D*)f->Get("h_Uni3");

  h2->SetTitle("babau");
  h3->SetTitle("babau");
  h3->SetFillColor(18);
  h2->SetFillColor(18);
  h1->SetFillColor(18);

  h3->Fit("gaus");

  TF1 *FitFun = h1->GetFunction("gaus");
  /*std::cout << "Ecco i parametri del fit " << endl;
  std::cout << "Media della gaussiana --->>> " << FitFun->GetParameter(1) << endl;
  std::cout << "Sigma della gaussiana --->>> " << FitFun->GetParameter(2) << endl;
  std::cout << "Chi2 del fit          --->>> " << FitFun->GetChisquare() << endl;*/

  TCanvas *c1 = new TCanvas("c1", "Canvas 1", 400, 10, 600, 700);
  //TCanvas *c2 = new TCanvas("c2", "Canvas 2", 400, 10, 600, 700);
  //TCanvas *c3 = new TCanvas("c3", "Canvas 3", 400, 10, 600, 700);
  c1->Divide(2,2);

  c1->cd(1);
  h1->SetMinimum(0.);
  h1->SetXTitle("x");
  h1->SetYTitle("N");
  h1->Draw();

  c1->cd(2);
  h2->SetMinimum(0.0);
  h2->SetMaximum(300.);  // use default or set as appropriate
  h2->SetXTitle("x");
  h2->SetYTitle("N");
  h2->Draw();

  c1->cd(3);
  h3->SetMinimum(0.0);
  h3->SetMaximum(550.);  // use default or set as appropriate
  h3->SetXTitle("x");
  h3->SetYTitle("N");
  h3->Draw();

  TLegend* leg = new TLegend(0.15, 0.7, 0.30, 0.8); // x1, y1, x2, y2
  leg->SetTextSize(0.04);
  leg->SetTextFont(42);
  leg->SetBorderSize(0);
  leg->SetFillColor(0);
  leg->AddEntry(h3, "Hist", "l");  // l for line, f for box, p for point
  leg->SetFillColor(19);
  leg->AddEntry(FitFun, "Fit", "l");
  //leg->AddEntry(FitFun->GetChisquare(), "Chi2");
  leg->Draw();
}
