#ifndef __Funzione_AJ_h__
#define __Funzione_AJ_h__

#include <iostream>
#include <cmath>
#include <TRandom3.h>

class RandomGen{
  public:

    RandomGen();
    double AR(double, double, double);
    double GetCount(){return count;};
    double GetTop(){return top;};

  private:
    TRandom3* ran1 = new TRandom3(12345);
    double count, top;
};


#endif
