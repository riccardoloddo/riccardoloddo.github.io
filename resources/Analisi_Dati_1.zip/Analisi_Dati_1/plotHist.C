// Simple ROOT macro to plot a histogram.
// Modify arguments as needed.
// To execute, type .X plotHist.C
{
  TFile* f = new TFile("simpleMC.root");
  f->ls();
  TH1D* h1 = (TH1D*)f->Get("h_Exp");
  TH1D* h2 = (TH1D*)f->Get("h_Exp1");
  h1->SetXTitle("f(x)");
  h1->SetYTitle("N");
  h2->SetXTitle("f(x)");
  h2->SetYTitle("N");
  h2->SetFillColor(18);
  h1->SetFillColor(18);
  h2->Draw();
}
