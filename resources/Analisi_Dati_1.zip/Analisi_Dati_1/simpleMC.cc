// Program to illustrate use of ROOT random number and histogram classes
// Glen Cowan, RHUL, Physics, November 2007

#include <iostream>
#include <cmath>
#include <TH1D.h>
#include <TFile.h>
#include <TRandom3.h>
#include "Funzione_AJ.h"

using namespace std;

int main(){

// Open output file (apparently needs to be done before booking)

  TFile* file = new TFile("simpleMC.root", "recreate");

// Book histograms


  TH1D* h_Uni = new TH1D("h_Uni1", "x = r_{1} + r_{2} -1",  100,  -2/2, 2/2);
  TH1D* h_Uni2 = new TH1D("h_Uni2", "x = #sum_{i=1}^{4} r_{i}-2",  100,  -4/2, 4/2);
  h_Uni2->SetTitleFont(8);
  TH1D* h_Uni3 = new TH1D("h_Uni3", "x = #sum_{i=1}^{12} r_{i}-6",  100,  -12/2, 12/2);
  TH1D* h_Exp = new TH1D("h_Exp", "Metodo Trasformata Inversa",  100,  -1, 2.0);
  TH1D* h_Exp1 = new TH1D("h_Exp1", "Metodo Accept-Reject",  100,  -1, 2.0);

// Create a TRandom3 object to generate random numbers

  int seed = 12345;
  TRandom3* ran = new TRandom3(seed);

// Generate some random numbers and fill histograms

  const int numValues = 10000;
  const double xi = 1.0;                // mean of exponential pdf


  double sum = 0;
  double r1 = 0;

  for (int i =0; i<numValues; i++) {
   double sum2 =0.;
   double sum4 =0.;
   double sum12 =0.;
   for (int k =0; k<12; k++) {
   r1 = ran->Rndm () ;
   if (k %6==0) sum2 += r1 ;
   if (k %3==0) sum4 += r1 ;
   sum12 += r1 ;
   }
   h_Uni -> Fill ( sum2 - 1.0) ;
   h_Uni2 -> Fill ( sum4 - 2.0) ;
   h_Uni3 -> Fill ( sum12 - 6.0) ;
 }

  for (int i=0; i<numValues; i++){
    r1 = ran->Uniform(0, 1);
    h_Exp->Fill(sqrt(r1));
  }

  RandomGen *czy = new RandomGen();
  double a = 0;

  for (int i=0; i<numValues; i++){
    a = czy->AR(0,1,2);
    cout<<" "<<a<<endl;
    h_Exp1->Fill(a);
  }

  cout<<"Cont: "<<czy->GetCount()<<endl;
  cout<<"Cont: "<<czy->GetTop()<<endl;
  cout<<"Efficienza: "<<czy->GetCount()/czy->GetTop()<<endl;

// Store all histograms in the output file and close up

  file->Write();
  file->Close();

  return 0;
}
