#include "Funzione_AJ.h"


RandomGen::RandomGen(){
}

double RandomGen::AR(double a, double b,double max){
  double s, t, x, y;
  do{
    s = ran1->Uniform(0, 1);
    t = ran1->Uniform(0, 1);
    x = a +(b-a)*s;
    y = max*t;
    top +=1;
    if(y < 2*x/b*b){
      count += 1;
    }
  }while(y > 2*x/b*b);

  return x;
}
