#include "Funzione_Base.h"

#define d 0.00001

Ampiezza::Ampiezza(double lambda){
  m_lambda = lambda;
}

Ampiezza::~Ampiezza(){};


double Ampiezza::Eval(double x) const{
  return pow( ( 1./(d)*cos( (2*M_PI/GetLambda())*(sqrt(1+pow(GetX() - x, 2) ) - sqrt(1+GetX()*GetX() )) ) ), m_a );
};
