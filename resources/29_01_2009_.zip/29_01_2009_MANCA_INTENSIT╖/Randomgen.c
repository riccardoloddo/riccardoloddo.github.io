#include "Randomgen.h"

RandomGen::RandomGen(unsigned int seed){
  m_seed = seed;
  m_a = 1664525;
  m_c = 1013904223;
  m_m = pow(2, 31);
}

double RandomGen::Random(){ //Mi genera un numero casuale tra 0 ed 1

    SetSeed( (GetA()*GetSeed() + GetC()) % GetM() );

    return (1.*GetSeed() )/(1.*GetM() );
}

double RandomGen::Uniform(double a, double b){  //Mi genera un numero casuale tra a ed b

  return a + (b - a)*Random();

}

double RandomGen::Exponential(double mean){  //Mi genera un numero casuale  in modo esponenziale SU TUTTO R

  return -(1./mean)*log(1 - Random() );

}

double RandomGen::Gauss(double mean, double sigma){  //Mi genera un numero casuale in modo NORMALE O GAUSSIANO centrato in mean e larghezza sigma

  double t = Random();
  double s = Random();
  double y = sqrt(-2*log(s))*cos(2*M_PI*t);

  return mean + y*sigma;
}

double RandomGen::GaussAr(double mean, double sigma){

  double x;
  double y;
  double s;
  double t;
  double a = mean - 5*sigma;
  double b = mean + 5*sigma;

  do{

    s = Random();
    t = Random();
    x = a +(b-a)*s;
    y = t*pow(sigma*sqrt(2*M_PI), -1);


  }while( y > pow(sqrt(2*M_PI), -1)*exp(-((x - mean)*(x - mean))/(2*sigma)) );

  return x;

}
