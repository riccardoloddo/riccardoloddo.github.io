#ifndef __Montecarlo_h__
#define __Montecarlo_h__

#include "Funzione_Base.h"
#include "Randomgen.h"

class MetodoMontecarlo{

public:

  virtual double Integral(FunzioneBase*, int) = 0 ; //Sto creando un metodo Eval che è generale. Ogni classe derivata dovra avere un metdo eval

};

class Media: public MetodoMontecarlo, RandomGen{


  public:

    Media(double, double);

    double GetA() const {return m_a; };
    double GetB() const {return m_b; };
    void SetA(double a) { m_a = a; };
    void SetB(double b) { m_b = b; };


    virtual double Integral(FunzioneBase*, int) ;

  private:
    double m_a, m_b;
};

class HitorMiss: public MetodoMontecarlo, RandomGen{


  public:

    HitorMiss(double, double, double);

    double GetA() const {return m_a; };
    double GetB() const {return m_b; };
    double GetMax() const {return m_max; };
    void SetA(double a) { m_a = a; };
    void SetB(double b) { m_b = b; };
    void SetMax(double max) { m_max = max; };


    virtual double Integral(FunzioneBase*, int) ;

  private:
    double m_a, m_b, m_max;
};













#endif
