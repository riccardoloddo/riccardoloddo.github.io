#include "Integrali.h"
#include "TCanvas.h"
#include "TApplication.h"
#include "TGraph.h"
#include "TAxis.h"
#include "TF1.h"
#include <iomanip>
#include "TLegend.h"
#include "Montecarlo.h"


using namespace std;

#define d 0.00001

int main() {

  TApplication app("App", 0, 0);

  TGraph* mygraph = new TGraph();
  TGraph* mygraph_3 = new TGraph();
  TGraph* mygraph_5 = new TGraph();
  FunzioneBase* amp = new Ampiezza(589E-9);
  Trapezi* integral_t = new Trapezi(-0.000005, 0.000005, 1000 );
  Media* med = new Media(-0.2, 0.2);
  int j = 0;

  amp->SetA(1);

  for( double x = -0.20; x<=0.2; x+= 0.001){
    amp->SetX(x);
    mygraph->SetPoint(j, x, integral_t->Integrale(amp, pow(10, -4) ) );
    j++;
  }

  j = 0;
  double sum = 0;

  for( double x = -0.20; x<=0.2; x+= 0.001){
    amp->SetX(x);
    sum = 0;
    for(int k = 0; k<3; k++){
      integral_t->SetA( (2*k-3+0.5)*d );
      integral_t->SetB( (2*k-3+1.5)*d );
      sum += integral_t->Integrale(amp, pow(10, -4) );
    }
    mygraph_3->SetPoint(j, x, sum );
    j++;
  }

  j = 0;
  for( double x = -0.20; x<=0.2; x+= 0.001){
    amp->SetX(x);
    sum = 0;
    for(int k = 0; k<5; k++){
      integral_t->SetA( (2*k-3+0.5)*d );
      integral_t->SetB( (2*k-3+1.5)*d );
      sum += integral_t->Integrale(amp, pow(10, -4) );
    }
    mygraph_5->SetPoint(j, x, sum );
    j++;
  }

  /*amp->SetA(2);
  sum = 0;
  for( double x = -0.20; x<=0.2; x+= 0.001){
    amp->SetX(x);
    sum += med->Integral(amp, pow(10, 4));
    j++;
  }
  cout<<"L'intensità della luce trasmessa con n = 1 è: "<<sum<<endl;*/

  TCanvas *mycanvas = new TCanvas();
  mycanvas->cd();
  mycanvas->SetGrid(1,1);
  mygraph->SetTitle("Difrazione_λ_589nm");
  mygraph->GetXaxis()->SetTitle(" Posizione x [m] ");
  mygraph->GetYaxis()->SetTitle(" Ampiezza [m] ");
  mygraph->SetLineColor(4);
  mygraph->Draw("ALP");

  TCanvas *mycanvas1 = new TCanvas();
  mycanvas1->cd();
  mycanvas1->SetGrid(1,1);
  mygraph_3->SetTitle("Sovrapposizione_3_Interferenze");
  mygraph_3->GetXaxis()->SetTitle(" Posizione x [m] ");
  mygraph_3->GetYaxis()->SetTitle(" Ampiezza [m] ");
  mygraph_3->SetLineColor(2);
  mygraph_3->Draw("ALP");

  TCanvas *mycanvas2 = new TCanvas();
  mycanvas2->cd();
  mycanvas2->SetGrid(1,1);
  mygraph_5->SetTitle("Sovrapposizione_5_Interferenze");
  mygraph_5->GetXaxis()->SetTitle(" Posizione x [m] ");
  mygraph_5->GetYaxis()->SetTitle(" Ampiezza [m] ");
  mygraph_5->SetLineColor(2);
  mygraph_5->Draw("ALP");

  app.Run();



  return 0;

}
