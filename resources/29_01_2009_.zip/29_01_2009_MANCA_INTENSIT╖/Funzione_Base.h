#ifndef __Funzione_Base_h__
#define __Funzione_Base_h__

#include <iostream>
#include <cmath>

using namespace std;

class FunzioneBase{

  public:

    void SetX(double x) {m_x1 = x; };
    void SetA(int a) {m_a = a; };
    double GetX() const {return m_x1; };
    virtual double Eval(double x) const = 0 ; //Sto creando un metodo Eval che è generale. Ogni classe derivata dovra avere un metdo eval

  protected:
    double m_x1;
    int m_a;
};


class Ampiezza : public FunzioneBase{

  public:

    Ampiezza(double);
    ~Ampiezza();


    double GetLambda() const { return m_lambda; };

    virtual double Eval(double x) const;

  private:
    double m_lambda, m_x1;

};

#endif
