#include "Integrali.h"

MidPoint::MidPoint(double xmin, double xmax, int passi){ //L'esercizio dice con un numero di passi fissato quindi nel costruttore
                                                         //faccio prendere il numero di passi
  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
  m_passi = passi;
};

MidPoint::~MidPoint(){ ; };

double MidPoint::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 1;

  do {
    integral = 0;
    half_integral = 0;
    h = (m_b - m_a)/double(i);
    for(int p = 0; p < i; p++){
      integral += f->Eval(m_a + (p + 0.5)*h)*h;
    }
    for(int p = 0; p < i*2; p++){ //devo metterci *2 poichè h e dimezzato quindi il numero di passi  doppio, devo sommare il doppio delle cose.
      half_integral += f->Eval(m_a + (p + 0.5)*h*0.5)*(h*0.5);
    }
    i *= 2;
  }while((4./3.)*fabs(integral - half_integral) > prec);

  return integral;

};

double MidPoint::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = 0;

  for(int p = 0; p < m_passi; p++)
    integral += f->Eval(m_a + (p + 0.5)*h);

  return integral*h;

};

Simpson::Simpson(double xmin, double xmax, int passi){ //L'esercizio dice con un numero di passi fissato quindi nel costruttore
                                                         //faccio prendere il numero di passi
  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
  m_passi = passi;
};

Simpson::~Simpson(){ ; };

double Simpson::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 2;

  do {
    integral = f->Eval(m_a) + f->Eval(m_b);
    half_integral = f->Eval(m_a) + f->Eval(m_b);
    h = (m_b - m_a)/double(i);
    for(int p = 1; p < i; p += 2){
      integral += 4*f->Eval(m_a + p*h) + 2*f->Eval(m_a + (p+1)*h);
    }
    for(int p = 1; p < i*2; p += 2){
      half_integral += 4*f->Eval(m_a + p*h*0.5) + 2*f->Eval(m_a + (p+1)*h*0.5);
    }
    i +=2;
  }while((16./15.)*fabs(integral*h - half_integral*h*0.5) > prec);

  return integral*h/double(3);

};

double Simpson::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = f->Eval(m_a) + f->Eval(m_b);

  for(int p = 1; p < m_passi; p += 2)
    integral += 4*f->Eval(m_a + p*h) + 2*f->Eval(m_a + (p+1)*h);

  return integral*h/double(3);

};


Trapezi::Trapezi(double xmin, double xmax, int passi){ //L'esercizio dice con un numero di passi fissato quindi nel costruttore
                                                         //faccio prendere il numero di passi
  if(xmin > xmax){
    double temp = xmin;
    xmin = xmax;
    xmax = temp;
  }
  m_a = xmin;
  m_b = xmax;
  m_passi = passi;
};

Trapezi::~Trapezi(){ ; };

double Trapezi::Integrale(const FunzioneBase* f, double prec) const {

  double h = 0;
  double integral = 0;
  double half_integral = 0;
  int i = 1;

  do {
    integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;
    half_integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;
    h = (m_b - m_a)/double(i);
    for(int p = 1; p < i; p++){
      integral += f->Eval(m_a + p*h) ;
      //cout<<"integral: "<<integral<<endl;
    }
    for(int p = 1; p < i*2; p++){
      half_integral += f->Eval(m_a + p*h*0.5);
      //cout<<"half_integral: "<<half_integral<<endl;
    }
    i *= 2;
    }while((4./3.)*(fabs(integral*h - half_integral*h*0.5)) > prec);

  return integral*h;

};

double Trapezi::Integrale(const FunzioneBase* f) const {

  double h = (m_b - m_a)/m_passi;
  double integral = (f->Eval(m_a) + f->Eval(m_b))*0.5;

  for(int p = 1; p < m_passi; p ++)
    integral += f->Eval(m_a + p*h) ;

  return integral*h;

};

//ATTENZIONE: HO DUE DOMANDE: 1) GLI ALGORITMI VANNO BENE (CREDO) PERO MI SA CHE half_integral PUÒ ESSERE DIRETTAMENTE CALCOLATO DA INTEGRAL;
//IN QUESTO MODO L'ALGORITMO È PIÙ EFFICENTE.
//LA SECONDA DOMANDA MENO IMPORTANTE È SE i++ È GIUSTO. NON DOVREI SEMPRE DIMEZZARE IL PASSSO? NEGLI ALTRI ES DELL ANNO SCORSO HO MESSO i *= 2.

//RICORDARSI ANCHE IL TF1 PERCHE VIENE COSI E CAPIRE SE E COME È POSSIBILE RICAVARE K1 (costante che moltiplica l'errore)
