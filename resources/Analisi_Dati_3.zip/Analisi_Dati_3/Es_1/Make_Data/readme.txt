The program makeData.cc is a standalone C++ program that uses ROOT
classes to generate some random values and puts them into a histogram.
To build the program at RHUL, download all the files to a separate
directory and type gmake.

Good luck,
 
GC
