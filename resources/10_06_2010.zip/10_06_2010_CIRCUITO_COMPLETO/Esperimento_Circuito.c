#include "Esperimento_Circuito.h"

using namespace std;


EsperimentoCircuito::EsperimentoCircuito() :

m_rand(1),
m_R1_input(90.),
m_R2_input(10),
m_R3_input(50),
m_sigmaRin(3.)

{
  SetRin( (GetR1()*GetR2() + GetR2()*GetR3() + GetR3()*GetR1() )/(GetR1() + GetR2()) );
}

EsperimentoCircuito::~EsperimentoCircuito(){}


void EsperimentoCircuito::Esegui(){

  SetR1M( m_rand.Gauss(GetR1(), GetSigmaR()) );
  SetR2M( m_rand.Gauss(GetR2(), GetSigmaR()) );
  SetR3M( m_rand.Gauss(GetR3(), GetSigmaR()) );


};


void EsperimentoCircuito::Analizza(){

  SetRinM( (GetR1M()*GetR2M() + GetR2M()*GetR3M() + GetR3M()*GetR1M())/(GetR1M() + GetR2M()) );

};
