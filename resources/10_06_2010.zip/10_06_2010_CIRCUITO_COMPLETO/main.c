#include "Esperimento_Circuito.h"
#include "TApplication.h"
#include "TCanvas.h"
#include "TAxis.h"
#include "TGraph.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TLegend.h"
#include "TGraph.h"
#include "TF1.h"
#include <algorithm>

using namespace std;

#define N 10000

int main(){

  TApplication app("app",0,0);

  EsperimentoCircuito *myCirc = new EsperimentoCircuito();

  myCirc->SetSigmaR(1.);
  TH1F *sigma1 = new TH1F("sigma1","Grafico_sigma1",100, myCirc->GetRin() - 5*myCirc->GetSigmaR(),  myCirc->GetRin() + 5*myCirc->GetSigmaR() );
  sigma1->StatOverflows( kTRUE );
  for(int i=0; i<N; i++){
    myCirc->Esegui();
    myCirc->Analizza();
    sigma1->Fill(myCirc->GetRinM() );
  }

  myCirc->SetSigmaR(3.);
  TH1F *sigma3 = new TH1F("sigma3","Grafico_sigma3",100, myCirc->GetRin() - 5*myCirc->GetSigmaR(),  myCirc->GetRin() + 5*myCirc->GetSigmaR() );
  sigma3->StatOverflows( kTRUE );
  for(int i=0; i<N; i++){
    myCirc->Esegui();
    myCirc->Analizza();
    sigma3->Fill(myCirc->GetRinM() );
  }

  myCirc->SetSigmaR(5.);
  TH1F *sigma5 = new TH1F("sigma5","Grafico_sigma5",100, myCirc->GetRin() - 5*myCirc->GetSigmaR(),  myCirc->GetRin() + 5*myCirc->GetSigmaR() );
  sigma5->StatOverflows( kTRUE );

  for(int i=0; i<N; i++){
    myCirc->Esegui();
    myCirc->Analizza();
    sigma5->Fill(myCirc->GetRinM() );
  }

  myCirc->SetSigmaR(7.);
  TH1F *sigma7 = new TH1F("sigma7","Grafico_sigma7",100, myCirc->GetRin() - 5*myCirc->GetSigmaR(),  myCirc->GetRin() + 5*myCirc->GetSigmaR() );
  sigma7->StatOverflows( kTRUE );
  for(int i=0; i<N; i++){
    myCirc->Esegui();
    myCirc->Analizza();
    sigma7->Fill(myCirc->GetRinM() );
  }

  myCirc->SetSigmaR(9.);
  TH1F *sigma9 = new TH1F("sigma9","Grafico_sigma9",100, myCirc->GetRin() - 5*myCirc->GetSigmaR(),  myCirc->GetRin() + 5*myCirc->GetSigmaR() );
  sigma9->StatOverflows( kTRUE );
  for(int i=0; i<N; i++){
    myCirc->Esegui();
    myCirc->Analizza();
    sigma9->Fill(myCirc->GetRinM() );
  }

  cout<<fixed;
  cout<<"La valutazione di Rin con sigma1 = 1 è: "<<setprecision(2)<<sigma1->GetMean()<<"Ω +/- "<<sigma1->GetRMS()<<"Ω"<<endl;
  cout<<"La valutazione di Rin con sigma3 = 3 è: "<<sigma3->GetMean()<<"Ω +/- "<<sigma3->GetRMS()<<"Ω"<<endl;
  cout<<"La valutazione di Rin con sigma5 = 5 è: "<<sigma5->GetMean()<<"Ω +/- "<<sigma5->GetRMS()<<"Ω"<<endl;
  cout<<"La valutazione di Rin con sigma7 = 7 è: "<<sigma7->GetMean()<<"Ω +/- "<<sigma7->GetRMS()<<"Ω"<<endl;
  cout<<"La valutazione di Rin con sigma9 = 9 è: "<<sigma9->GetMean()<<"Ω +/- "<<sigma9->GetRMS()<<"Ω"<<endl;

  TCanvas c0;
  c0.Divide(3,2);
  c0.cd(1);
  sigma1->GetXaxis()->SetTitle("Rin [Ω]");
  sigma1->GetYaxis()->SetTitle("Frequenza");
  sigma1->Draw();
  c0.cd(2);
  sigma3->GetXaxis()->SetTitle("Rin [Ω]");
  sigma3->GetYaxis()->SetTitle("Frequenza");
  sigma3->Draw();
  c0.cd(3);
  sigma5->GetXaxis()->SetTitle("Rin [Ω]");
  sigma5->GetYaxis()->SetTitle("Frequenza");
  sigma5->Draw();
  c0.cd(4);
  sigma7->GetXaxis()->SetTitle("Rin [Ω]");
  sigma7->GetYaxis()->SetTitle("Frequenza");
  sigma7->Draw();
  c0.cd(5);
  sigma9->GetXaxis()->SetTitle("Rin [Ω]");
  sigma9->GetYaxis()->SetTitle("Frequenza");
  sigma9->Draw();

  TGraph* myGraph = new TGraph();
  vector<double> sigma{sigma1->GetRMS(), sigma3->GetRMS(), sigma5->GetRMS(), sigma7->GetRMS(), sigma9->GetRMS()};

  for(int i = 0; i<5; i++){
    myGraph->SetPoint(i, 2*i +1, sigma[i]);
  }

  c0.cd(6);
  c0.SetGrid(1,1);
  myGraph->SetTitle("Grafico StdDev Rin in funzione di sigma");
  myGraph->GetXaxis()->SetTitle(" sigma [Ω] ");
  myGraph->GetYaxis()->SetTitle(" StdDev Rin [Ω] ");
  myGraph->SetLineColor(2);
  myGraph->SetMarkerStyle(20);
  myGraph->Draw("ALP");

  TLegend *mylegend = new TLegend(0.2,0.6,0.4,0.8);
  mylegend->AddEntry(myGraph,"This is StdDev","LP");
  mylegend->Draw();

  TF1* fitcampo0 = new TF1("fitcampo", "[0] + [1]*pow(x,[2])", 1, 10);
  myGraph->Fit(fitcampo0);

  cout<<"Il valore di simga_R per il quale si ha sigma_Rin = 3 è: "<<pow( ( 3.- fitcampo0->GetParameter(0) )/(fitcampo0->GetParameter(1) ), 1./fitcampo0->GetParameter(2) )<<"Ω"<<endl;

  app.Run();


return 0;

}
