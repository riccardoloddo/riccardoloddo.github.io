#ifndef __Esperimento_Circuito_h__
#define __Esperimento_Circuito_h__

#include "Randomgen.h"
#include <iostream>
#include <cmath>

class EsperimentoCircuito{
  public:

      EsperimentoCircuito();
      ~EsperimentoCircuito();

      void Esegui();
      void Analizza();

      double GetSigmaR() {return m_sigmaR; };
      void SetSigmaR(double a) {m_sigmaR = a; };

      double GetR1() const {return m_R1_input; };
      void SetR1(double a) {m_R1_input = a; };
      double GetR2() const {return m_R2_input; };
      void SetR2(double a) {m_R2_input = a; };
      double GetR3() const {return m_R3_input; };
      void SetR3(double a) {m_R3_input = a; };
      double GetRin() const {return m_Rin_input; };
      void SetRin(double a) {m_Rin_input = a; };

      double GetR1M() const {return m_R1_mis; };
      void SetR1M(double a) {m_R1_mis = a; };
      double GetR2M() const {return m_R2_mis; };
      void SetR2M(double a) {m_R2_mis = a; };
      double GetR3M() const {return m_R3_mis; };
      void SetR3M(double a) {m_R3_mis = a; };
      double GetRinM() const {return m_Rin_mis; };
      void SetRinM(double a) {m_Rin_mis = a; };

      double Minimo(double[]);
      double Massimo(double[]);

  private:

    RandomGen m_rand;

    double m_sigmaR;
    double m_sigmaRin;
    double m_R1_input, m_R2_input, m_R3_input;
    double m_R1_mis, m_R2_mis, m_R3_mis;
    double m_Rin_input, m_Rin_mis;

};

#endif
