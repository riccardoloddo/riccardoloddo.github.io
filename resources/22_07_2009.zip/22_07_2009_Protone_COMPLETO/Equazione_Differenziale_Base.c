#include "Equazione_Differenziale_Base.h"

Eulero::Eulero(){; };

vector<double> Eulero::Passo(const vector<double> &x, double t, double h, FunzioneVettorialeBase* f) const{

  return x + h*f->Eval(x, t);

};


RungeKutta::RungeKutta(){; };

vector<double> RungeKutta::Passo(const vector<double> &x, double t, double h, FunzioneVettorialeBase* f) const{

  vector<double> K1 = f->Eval(x, t);
  vector<double> K2 = f->Eval(x + 0.5*h*K1, t + 0.5*h);
  vector<double> K3 = f->Eval(x + 0.5*h*K2, t + 0.5*h);
  vector<double> K4 = f->Eval(x + h*K3, t + h);

  return x + (h/6.)*(K1 + 2.*K2 + 2.*K3 + K4);

};
