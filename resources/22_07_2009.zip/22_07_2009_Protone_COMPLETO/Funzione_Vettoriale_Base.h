#ifndef __Funzione_Vettoriale_Base_h__
#define __Funzione_Vettoriale_Base_h__

#include <iostream>
#include <cmath>
#include "operatori.h"

using namespace std;

class FunzioneVettorialeBase{

  public:

    //Eval accetta in imput x ed v e mi resituisce le derivte di x ed v. basta. tutte queste cose me le da il problema
    virtual vector<double> Eval(const vector<double> &p, double t) const = 0 ; //x è il vettore di partenza, ovvero quante posizione...quante velocità..

};


class Protone: public FunzioneVettorialeBase{

  public:

    Protone(double, double, double);

    virtual vector<double> Eval(const vector<double> &p, double t) const  ;

  private:

    double m_E0, m_p, q_p, m_lambda, m_freq;


};
#endif
