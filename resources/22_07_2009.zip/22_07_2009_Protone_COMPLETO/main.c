#include "Equazione_Differenziale_Base.h"
#include "TCanvas.h"
#include "TApplication.h"
#include "TGraph.h"
#include "TAxis.h"
#include "TF1.h"
#include <iomanip>
#include "TLegend.h"

using namespace std;

int main() {

  TApplication myapp("myapp", 0, 0); //Crea un ambiente applicativo

  Protone * prot = new Protone(pow(10., 7), 0.2, 5.*pow(10., 8));
  RungeKutta * rk = new RungeKutta();
  TGraph* mygraph = new TGraph();
  TGraph* mygraph1 = new TGraph();
  TGraph* mygraph2 = new TGraph();
  double h = 10E-12;
  double tmax = pow(10, -7 );
  int nstep = int(tmax/h +0.5);
  double t = 0;
  vector<double> x {0.03, pow(10, 8)};

  for(int i = 0; i<nstep; i++){ //qui il for posso scriverlo in termini come se i fosse il tempo? come farei?
    mygraph->SetPoint(i, t, x[1]);
    x = rk->Passo(x, t, h, prot);
    t = t+h;
  }
  t = 0;
  vector<double> x1 {0.06, pow(10, 8)};
  for(int i = 0; i<nstep; i++){ //qui il for posso scriverlo in termini come se i fosse il tempo? come farei?
    mygraph1->SetPoint(i, t, x1[1]);
    x1 = rk->Passo(x1, t, h, prot);
    t = t+h;
  }
  t = 0;
  vector<double> x2 {0.09, pow(10, 8)};
  for(int i = 0; i<nstep; i++){ //qui il for posso scriverlo in termini come se i fosse il tempo? come farei?
    mygraph2->SetPoint(i, t, x2[1]);
    x2 = rk->Passo(x2, t, h, prot);
    t = t+h;
  }

  TCanvas *mycanvas = new TCanvas();
  mycanvas->cd();
  mycanvas->SetGrid(1,1);
  mygraph->SetTitle("v(t) Protone");
  mygraph->GetXaxis()->SetTitle("Tempo [s]");
  mygraph->GetYaxis()->SetTitle("Velocità [m/s]");
  mygraph->GetYaxis()->SetRangeUser(85E6, 115E6);
  mygraph->SetLineColor(2); //rosso
  mygraph1->SetLineColor(3); //verde
  mygraph2->SetLineColor(5); //giallo
  mygraph->Draw("ALL");
  mygraph1->Draw("sameL");
  mygraph2->Draw("sameL");

  TLegend *mylegend = new TLegend(0.2,0.6,0.4,0.8);
  mylegend->AddEntry(mygraph,"This is x = 0.03","LP");
  mylegend->AddEntry(mygraph1,"This is x = 0.06","LP");
  mylegend->AddEntry(mygraph2,"This is x = 0.09","LP");
  mylegend->Draw();

  vector<double> Vel;
  vector<double> Amp;
  vector<double> Err;

  for(double p = 0; p < 0.21; p += 0.01){
    x[0] = p;
    x[1] = pow(10, 8);
    t = 0;
    for(int i = 0; i<nstep; i++){ //qui il for posso scriverlo in termini come se i fosse il tempo? come farei?
      Vel.push_back(x[1]);
      x = rk->Passo(x, t, h, prot);
      t = t+h;
    }

    Amp.push_back( (*max_element(Vel.begin(), Vel.end()) - *min_element(Vel.begin(), Vel.end()))*0.5 );
    Err.push_back( (*max_element(Vel.begin(), Vel.end()) + *min_element(Vel.begin(), Vel.end()))*0.5 - pow(10, 8) );
    Vel.clear();

    //cout<<p<<endl;

    cout<<"Vmin: "<<*min_element(Vel.begin(), Vel.end())<<"alla posizione: "<<p<<endl;
    cout<<"Vmax: "<<*max_element(Vel.begin(), Vel.end())<<endl;
    cout<<"Vmax - vmin: "<<*max_element(Vel.begin(), Vel.end()) - *min_element(Vel.begin(), Vel.end())<<endl<<endl;
  }

  TGraph* mygraph3 = new TGraph();
  double k=0;

  for(int i = 0; i < Amp.size(); i++ ){
    mygraph3->SetPoint(i, k, Amp[i]);
    k += 0.01;
  }

  TCanvas *mycanvas1 = new TCanvas();
  mycanvas1->cd();
  mycanvas1->SetGrid(1,1);
  mygraph3->SetTitle("Ampiezza oscillazione Protone");
  mygraph3->GetXaxis()->SetTitle("Posizione_iniziale [m]");
  mygraph3->GetYaxis()->SetTitle("Ampiezza [m/s]");
  mygraph3->SetMarkerStyle(20);
  mygraph3->Draw("ALP");


  TGraph* mygraph4 = new TGraph();
  double j=0;

  for(int i = 0; i < Amp.size(); i++ ){
    mygraph4->SetPoint(i, j, Err[i]);
    j += 0.01;
  }

  TCanvas *mycanvas2 = new TCanvas();
  mycanvas2->cd();
  mycanvas2->SetGrid(1,1);
  mygraph4->SetTitle("Errore velocità Protone");
  mygraph4->GetXaxis()->SetTitle("Posizione_iniziale [m]");
  mygraph4->GetYaxis()->SetTitle("Errore [m/s]");
  mygraph4->SetMarkerStyle(20);
  mygraph4->Draw("ALP");

  myapp.Run();

return 0;

}
