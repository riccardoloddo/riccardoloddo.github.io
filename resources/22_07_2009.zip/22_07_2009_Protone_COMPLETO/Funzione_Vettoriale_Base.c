#include "Funzione_Vettoriale_Base.h"

#define g 9.80665

Protone::Protone(double elettro, double lambda, double frequenza){
  m_E0 = elettro;
  m_p = 1.67262192369E-27;
  q_p = 1.602176634E-19;
  m_lambda = lambda;
  m_freq = frequenza;
};

vector<double> Protone::Eval(const vector<double> &p, double t) const {

  vector<double> dpdt {p[1], -(q_p/m_p)*m_E0*sin( (2.*M_PI*p[0]/m_lambda) - 2*M_PI*m_freq*t)};

  return dpdt;
};
