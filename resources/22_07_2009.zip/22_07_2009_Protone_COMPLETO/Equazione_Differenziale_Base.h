#ifndef __Equazione_Differenziale_Base_h__
#define __Equazione_Differenziale_Base_h__

#include "Funzione_Vettoriale_Base.h"

using namespace std;

class EquazioneDifferenzialeBase{

  public:

    virtual vector<double> Passo(const vector<double> &x, double t, double h, FunzioneVettorialeBase* f) const = 0 ; //Sto creando un metodo Eval che è generale. Ogni classe derivata dovra avere un metdo eval

};

class Eulero : public EquazioneDifferenzialeBase{

  public:

    Eulero();

    virtual vector<double> Passo(const vector<double> &x, double t, double h, FunzioneVettorialeBase* f) const;

};

class RungeKutta : public EquazioneDifferenzialeBase{

  public:

    RungeKutta();

    virtual vector<double> Passo(const vector<double> &x, double t, double h, FunzioneVettorialeBase* f) const;

};


#endif
