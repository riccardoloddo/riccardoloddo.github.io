#include "Esperimento_Ponte_a_filo.h"
#include "TApplication.h"
#include "TCanvas.h"
#include "TAxis.h"
#include "TGraph.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TLegend.h"
#include "TGraph.h"
#include "TF1.h"
#include <algorithm>

using namespace std;


int main(){

  TApplication app("app",0,0);

  EsperimentoPonteFilo *myExp = new EsperimentoPonteFilo();

  TH1F graf ("R30", "Grafico_X_R30,", 100, 450,  550 );
  TGraph* Error = new TGraph();
  vector<TH1F> myGraph;
  vector<int> R { 200, 500, 900, 1500, 3000 };
  string name;  //= "Grafico_X_R"+to_string(R[j]);

  for(int j = 0; j<R.size(); j++){
    myExp->SetRin(R[j]);
    myExp->SetSigmaR( myExp->GetRin()*5*pow(10, -3) );
    name = "Grafico_X_R"+to_string(R[j]);
    graf.SetTitle( name.c_str() );
    graf.GetXaxis()->SetTitle("Resistenza_X [Ohm]");
    graf.GetYaxis()->SetTitle("Frequenza");
    for(int i=0; i<1000; i++){
      myExp->Esegui();
      myExp->Analizza();
      graf.Fill( myExp->GetXmis() );
  }
  cout<<"l1: "<<myExp->Getl1in()<<endl;
  myGraph.push_back( graf );
}

TCanvas* myCanvas = new TCanvas();

myCanvas->Divide(3,2);

for(int i=0; i<myGraph.size(); i++){
  myCanvas->cd(i+1);
  myGraph[i].Draw();
  cout<<endl<<"La resistenza incognita è: "<<myGraph[i].GetMean()<<" +/- "<<myGraph[i].GetStdDev()<<endl;
}

for(int i=0; i<myGraph.size(); i++){
  Error->SetPoint(i, R[i], fabs(  myGraph[i].GetStdDev() ) );
}

TCanvas* myErr = new TCanvas();
myErr->cd();
Error->SetTitle("Errore in funzione di R");
Error->GetXaxis()->SetTitle("R [Ohm]");
Error->GetYaxis()->SetTitle("Err");
Error->SetMarkerStyle(20);
Error->Draw("ALP");

cout<<"La risistenza ottimale è quella con R = 900 Ohm. "<<endl;

app.Run();


return 0;

}
