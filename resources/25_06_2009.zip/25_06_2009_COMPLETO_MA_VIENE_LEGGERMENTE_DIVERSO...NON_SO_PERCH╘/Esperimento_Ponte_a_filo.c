#include "Esperimento_Ponte_a_filo.h"

using namespace std;


EsperimentoPonteFilo::EsperimentoPonteFilo() :

m_rand(1),
m_X_input(500),
m_L_tot(1),
m_sigmal1(0.002)

{



}

EsperimentoPonteFilo::~EsperimentoPonteFilo(){}


void EsperimentoPonteFilo::Esegui(){

  Setl1in( GetL()*GetRin()/(GetXin() + GetRin() ) );

  Setl2in( GetL() - Getl1in() );

  Setl1mis( m_rand.Gauss( Getl1in(), m_sigmal1 ) );

  SetRmis( m_rand.Gauss( GetRin(), GetSigmaR() ) );

};


void EsperimentoPonteFilo::Analizza(){

  Setl2mis( GetL() - Getl1mis() );

  SetXmis( GetRmis()*Getl2mis()/Getl1mis() );


};
