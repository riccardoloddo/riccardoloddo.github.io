#ifndef __Esperimento_Ponte_a_filo_h__
#define __Esperimento_Ponte_a_filo_h__

#include "Randomgen.h"
#include <iostream>
#include <cmath>

class EsperimentoPonteFilo{
  public:

      EsperimentoPonteFilo();
      ~EsperimentoPonteFilo();

      void Esegui();
      void Analizza();

      //Resistenza R
      double GetRin() {return m_R_input; };
      void SetRin(double r) { m_R_input = r; };
      double GetRmis() {return m_R_misurato; };
      void SetRmis(double r) {m_R_misurato = r; };
      //Lunghezza senza sigma
      double GetL() {return m_L_tot; };
      void SetL(double r) { m_L_tot = r; };
      //Resistenza incognita
      double GetXin() {return m_X_input; };
      void SetXin(double r) { m_X_input = r; };
      double GetXmis() {return m_X_misurato; };
      void SetXmis(double r) {m_X_misurato = r; };
      //Lunghezza l1
      double Getl1in() {return m_l1_input; };
      void Setl1in(double r) { m_l1_input = r; };
      double Getl1mis() {return m_l1_misurato; };
      void Setl1mis(double r) {m_l1_misurato = r; };
      //Lunghezza l2
      double Getl2in() {return m_l2_input; };
      void Setl2in(double r) { m_l2_input = r; };
      double Getl2mis() {return m_l2_misurato; };
      void Setl2mis(double r) {m_l2_misurato = r; };
      //Sigma R
      double GetSigmaR() {return m_sigma_R; };
      void SetSigmaR(double r) { m_sigma_R = r; };//MI DEVO RICORDARE DI METTERLO

  private:

    RandomGen m_rand;

    double m_X_input, m_X_misurato;
    double m_L_tot, m_l2_input, m_l1_input, m_l2_misurato, m_l1_misurato;
    double m_R_input, m_R_misurato;
    double m_sigmal1, m_sigma_R;


};

#endif
