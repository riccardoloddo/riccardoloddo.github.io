#include <iostream>
#include <fstream>
#include <vector>
#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TCanvas.h>
#include <TApplication.h>
#include <TROOT.h>
#include <TStyle.h>
#include <TPad.h>
#include <TAxis.h>
#include <TH2F.h>
#include <TF2.h>
#include <TLine.h>
#include "Event.h"
#include "OutFunc.h"
#include <TMVA/Reader.h>
#include <TGraph.h>
#include <TApplication.h>
#include <TLegend.h>

using namespace std;

OutFunc* testStat;      // need global for contour later

OutFunc* testStat_MvP;

OutFunc* testStat_BDT;

OutFunc* testStat_auto;

int main() {

  TApplication app("App",0,0);

// Set up an output file and book some histograms

  TFile* histFile = new TFile("analysis.root", "RECREATE");
  TH1D* hSig = new TH1D("hSig", "Fisher, signal", 100, -5.0, 5.0);
  TH1D* hBkg = new TH1D("hBkg", "Fisher, background", 100, -5.0, 5.0);
  TH1D* hSig_Mvp = new TH1D("hSig_Mvp", "MLP, signalMvp", 100, -0.5, 1.5);
  TH1D* hBkg_Mvp = new TH1D("hBkg_Mvp", "MLP, backgroundMvp", 100, -0.5, 1.5);
  TH1D* hSig_BDT = new TH1D("hSig_BDT", "BDT, signalBDT", 100, -2.0, 2.0);
  TH1D* hBkg_BDT = new TH1D("hBkg_BDT", "BDT, backgroundBDT", 100, -2.0, 2.0);
  TH1D* hSig_BDT1 = new TH1D("hSig_BDT1", "BDT, signalBDT1", 100, -2.0, 2.0);
  TH1D* hBkg_BDT1 = new TH1D("hBkg_BDT1", "BDT, backgroundBDT1", 100, -2.0, 2.0);
  TGraph* func_sig = new TGraph();
  TGraph* func_bkg = new TGraph();
  func_sig->SetTitle("funcsig");
  func_bkg->SetTitle("funcbkg");

  TList* hList = new TList();      // list of histograms to store
  hList->Add(hSig);
  hList->Add(hBkg);
  hList->Add(hSig_Mvp);
  hList->Add(hBkg_Mvp);
  hList->Add(hSig_BDT);
  hList->Add(hBkg_BDT);
  hList->Add(hSig_BDT1);
  hList->Add(hBkg_BDT1);
  hList->Add(func_sig);
  hList->Add(func_bkg);

// Set up the OutFunc object.  First argument must be one of the classifiers.
// 4th argument is offset for contour.
// 5th argument is bool array indicating which variables were used in training

  std::string dir    = "../train/dataset/weights/";
  std::string prefix = "tmvaTest";
  const double tCut = 0.;
  const double tCut_Mvp = 0.5;
  const double tCut_BDT = 0.;
  std::vector<bool> useVar(3);
  useVar[0] = true;      // x
  useVar[1] = true;      // y
  useVar[2] = true;      // z
  testStat = new OutFunc("Fisher", dir, prefix, tCut, useVar);
  testStat_MvP = new OutFunc("MLP", dir, prefix, tCut, useVar);
  testStat_BDT = new OutFunc("BDT200", dir, prefix, tCut, useVar);

// Open input file, get the TTrees, put into a vector

  TFile* inputFile = new TFile("../generate/testData.root");
  inputFile->ls();

  TFile* inputFile_training = new TFile("../generate/trainingData.root");
  inputFile_training->ls();

  TTree* sig = dynamic_cast<TTree*>(inputFile->Get("sig"));
  TTree* bkg = dynamic_cast<TTree*>(inputFile->Get("bkg"));

  TTree* sig_training = dynamic_cast<TTree*>(inputFile_training->Get("sig"));
  TTree* bkg_training = dynamic_cast<TTree*>(inputFile_training->Get("bkg"));

  std::vector<TTree*> treeVec;
  treeVec.push_back(sig);
  treeVec.push_back(bkg);

  std::vector<TTree*> treeVec1;
  treeVec1.push_back(sig_training);
  treeVec1.push_back(bkg_training);

// Loop over TTrees, i=0 is signal, i=1 is background

 //cout<<"primo???"<<treeVec[0]->GetEntry(0)<<endl;

  int nSig, nBkg;
  int nSigMvp, nBkgMvp;
  int nSigBDT, nBkgBDT;
  int nSigBDT1, nBkgBDT1;
  int nSigAcc = 0;
  int nBkgAcc = 0;
  int nSigAcc_MvP = 0;
  int nBkgAcc_MvP = 0;
  int nSigAcc_BDT = 0;
  int nBkgAcc_BDT = 0;

  for (int i=0; i<treeVec.size(); i++){

    treeVec[i]->Print();
    Event evt;
    treeVec[i]->SetBranchAddress("evt", &evt);
    int numEntries = treeVec[i]->GetEntries();
    if ( i == 0 ) { nSig = numEntries; }
    if ( i == 1 ) { nBkg = numEntries; }
    std::cout << "number of entries = " << numEntries << std::endl;

    for (int j=0; j<numEntries; j++){

      treeVec[i]->GetEntry(j);
      double t = testStat->val(&evt);

      if ( i == 0 ){
        hSig->Fill(t);
	      if ( t > tCut ) { nSigAcc++; }
      }
      else if ( i == 1 ){
        hBkg->Fill(t);
        if ( t >= tCut ) { nBkgAcc++; }
      }
      /*else if ( i == 1 ){
        hBkg->Fill(t);
        if ( t > tCut ) { nSigAcc++; }
      }*/
    }
  }

  double epsSig = static_cast<double>(nSigAcc)/static_cast<double>(nSig);
  double epsBkg = static_cast<double>(nBkgAcc)/static_cast<double>(nBkg);
  cout << "nSigAcc, nSig = " << nSigAcc << " , " << nSig << endl;
  cout << "nBkgAcc, nBkg = " << nBkgAcc << " , " << nBkg << endl;
  std::cout << "signal efficiency (power) = " << epsSig << std::endl;
  std::cout << "backround efficiency (power) = " << epsBkg << std::endl;
  std::cout << "purity = " << static_cast<double>(nSigAcc)/(static_cast<double>(nSigAcc) + static_cast<double>(nBkgAcc)) << std::endl;
  //std::cout << "purity_dd = " << static_cast<double>(nSigAcc)/(nBkgAcc) << std::endl;
  std::cout << "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP = " <<endl;


  for (int i=0; i<treeVec.size(); i++){ //treeVec.size() è uguale a 2.

    treeVec[i]->Print();
    Event evt;
    treeVec[i]->SetBranchAddress("evt", &evt);
    int numEntries = treeVec[i]->GetEntries(); //sto assegando a numEntries il numero di segnali (quando i = 0) e il numero di background quando i =1
    //sono entrambi 10.000 eventi.
    if ( i == 0 ) { nSigMvp = numEntries; }
    if ( i == 1 ) { nBkgMvp = numEntries; }
    std::cout << "number of entries = " << numEntries << std::endl;

  for (int j=0; j<numEntries; j++){

    treeVec[i]->GetEntry(j);                   // sets evt
    //quando j = 0 sto selezionndo il primo valre di sig che è 12.

    double tmlp = testStat_MvP->val(&evt);            // evaluate test statistic
    //cout << t << " " << evt.x << "  " << evt.y << endl;

    if ( i == 0 ){                       // signal
      hSig_Mvp->Fill(tmlp);
      if ( tmlp >= tCut_Mvp ) { nSigAcc_MvP++; } //prendo gli eventi di segnale
    }
    else if ( i == 1 ){                  // background
      hBkg_Mvp->Fill(tmlp);
      if ( tmlp >= tCut_Mvp ) { nBkgAcc_MvP++; }
    }
  }
}

double epsSig_MvP = static_cast<double>(nSigAcc_MvP)/static_cast<double>(nSig);
double epsBkg_MvP = static_cast<double>(nBkgAcc_MvP)/static_cast<double>(nBkg);
cout << "nSigAcc_MLP, nSigMvp = " << nSigAcc_MvP << " , " << nSigMvp << endl;
cout << "nBkgAcc_MLP, nBkgMvp = " << nBkgAcc_MvP << " , " << nBkgMvp << endl;
std::cout << "signal efficiency (power) MLP = " << epsSig_MvP << std::endl;
std::cout << "backround efficiency (power) MLP = " << epsBkg_MvP << std::endl;
std::cout << "purity = " << static_cast<double>(nSigAcc_MvP)/(static_cast<double>(nSigAcc_MvP) + static_cast<double>(nBkgAcc_MvP)) << std::endl;
std::cout << "OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO = " <<endl;


for (int i=0; i<treeVec.size(); i++){ //treeVec.size() è uguale a 2.

  treeVec[i]->Print();
  Event evt;
  treeVec[i]->SetBranchAddress("evt", &evt);
  int numEntries = treeVec[i]->GetEntries(); //sto assegando a numEntries il numero di segnali (quando i = 0) e il numero di background quando i =1
  //sono entrambi 10.000 eventi.
  if ( i == 0 ) { nSigBDT = numEntries; }
  if ( i == 1 ) { nBkgBDT = numEntries; }
  std::cout << "number of entries = " << numEntries << std::endl;

for (int j=0; j<numEntries; j++){

  treeVec[i]->GetEntry(j);
  double tBDT = testStat_BDT->val(&evt);

  if ( i == 0 ){
    hSig_BDT->Fill(tBDT);
    if ( tBDT >= tCut_BDT ) { nSigAcc_BDT++; }
  }
  else if ( i == 1 ){
    hBkg_BDT->Fill(tBDT);
    if ( tBDT >= tCut_BDT ) { nBkgAcc_BDT++; }
  }
}
}



int nSigAcc_BDT1 = 0;
int nBkgAcc_BDT1 = 0;
for (int i=0; i<treeVec1.size(); i++){ //treeVec.size() è uguale a 2.

  treeVec1[i]->Print();
  Event evt;
  treeVec1[i]->SetBranchAddress("evt", &evt);
  int numEntries = treeVec1[i]->GetEntries();
  if ( i == 0 ) { nSigBDT1 = numEntries; }
  if ( i == 1 ) { nBkgBDT1 = numEntries; }
  std::cout << "number of entries = " << numEntries << std::endl;

  for (int j=0; j<numEntries; j++){

    treeVec1[i]->GetEntry(j);

    double tBDT1 = testStat_BDT->val(&evt);

    if ( i == 0 ){                       // signal
      hSig_BDT1->Fill(tBDT1);
      if ( tBDT1 >= tCut_BDT ) { nSigAcc_BDT1++; } //prendo gli eventi di segnale
    }
    else if ( i == 1 ){                  // background
      hBkg_BDT1->Fill(tBDT1);
      if ( tBDT1 <= tCut_BDT ) { nBkgAcc_BDT1++; }
    }
  }
}




//tasso di errore totale.


double vec[12] = {1,2,5,10,20,50,100,200,500,1000,10000,50000};
//double vec[10] = {1,2,5,10,20,50,100,200,500,1000};
std::string a;
std::vector<double> tasso_sig;
std::vector<double> tasso_bkg;

for(int k=0; k<12; k++){
  a = "BDT"+std::to_string(vec[k]);
  testStat_auto = new OutFunc(a, dir, prefix, tCut, useVar);

  int nSig_auto, nBkg_auto;
  int nSigAcc_auto = 0;
  int nBkgAcc_auto = 0;

  for (int i=0; i<treeVec.size(); i++){

    treeVec[i]->Print();
    Event evt;
    treeVec[i]->SetBranchAddress("evt", &evt);
    int numEntries = treeVec[i]->GetEntries();
    if ( i == 0 ) { nSig_auto = numEntries; }
    if ( i == 1 ) { nBkg_auto = numEntries; }
    std::cout << "number of entries = " << numEntries << std::endl;

    for (int j=0; j<numEntries; j++){

      treeVec[i]->GetEntry(j);
      double t = testStat_auto->val(&evt);

      if ( i == 0 ){
	      if ( t <= tCut ) { nSigAcc_auto++; }
      }
      else if ( i == 1 ){
        if ( t >= tCut ) { nBkgAcc_auto++; }
      }
    }
  }
  tasso_sig.push_back(static_cast<double>(nSigAcc_auto)/static_cast<double>(nSig_auto));
  tasso_bkg.push_back(static_cast<double>(nBkgAcc_auto)/static_cast<double>(nSig_auto));
  func_sig->SetPoint(k,vec[k],tasso_sig[k]);
  func_bkg->SetPoint(k,vec[k],tasso_bkg[k]);
}

for(int i = 0; i<tasso_sig.size(); i++){
  cout<<"tasso_sig:"<<tasso_sig[i]<<endl;
}

TCanvas* mygraph = new TCanvas("mygraph", "mygraph4");

  func_sig->SetMaximum(0.16);
  mygraph->SetLogx();
  func_sig->SetLineColor(2);
  func_sig->SetLineWidth(3);
  func_sig->GetYaxis()->SetTitle("n");
  func_sig->GetYaxis()->SetTitle("Err");
  func_sig->SetTitle("Tasso di errore totale");
  func_bkg->SetLineWidth(3);
  func_bkg->SetLineColor(4); //blue = bkg
  func_sig->Draw("AL*");
  func_bkg->Draw("same");

  TLegend* leg4 = new TLegend(0.2, 0.72, 0.4, 0.88); // x1, y1, x2, y2
  leg4->SetTextSize(0.04);
  leg4->SetTextFont(42);
  leg4->SetBorderSize(0);
  leg4->SetFillColor(0);
  leg4->AddEntry(func_sig, "  signalBDT", "l");
  leg4->AddEntry(func_bkg, "  backgroundBDT", "l");
  leg4->Draw();

  app.Run();

//  Compute efficiencies (power, size)





// Close up

  inputFile->Close();
  inputFile_training->Close();
  histFile->Write();
  histFile->Close();

  return 0;

}
