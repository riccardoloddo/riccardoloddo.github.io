{

  // Set some defaults
  gROOT->Reset();
  gROOT->SetStyle("Plain");
  gStyle->SetCanvasBorderMode(0); // turn off canvas borders
  gStyle->SetOptStat(0);
  gStyle->SetTitleBorderSize(0);
  gStyle->SetTitleFont(42, "h");        // for histogram title
  gStyle->SetTitleFont(42, "xyz");      // for axis labels
  gStyle->SetLabelFont(42, "xyz");      // for axis values
  gStyle->SetTitleSize(0.04, "h");
  gStyle->SetTitleSize(0.04, "xyz");
  gStyle->SetPadLeftMargin(0.17);
  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadTopMargin(0.08);
  gStyle->SetPadBottomMargin(0.17);
  gStyle->SetTitleAlign(33);
  gStyle->SetTitleX(0.55);

  gROOT->ForceStyle();

  // Open the file and list its contents, get the Ttrees
  TFile* f = new TFile("analysis.root");
  f->ls();
  TH1D* hSig = (TH1D*)f->Get("hSig");
  TH1D* hBkg = (TH1D*)f->Get("hBkg");
  TH1D* hSigMvp = (TH1D*)f->Get("hSig_Mvp");
  TH1D* hBkgMvp = (TH1D*)f->Get("hBkg_Mvp");
  TH1D* hSigBDT = (TH1D*)f->Get("hSig_BDT");
  TH1D* hBkgBDT = (TH1D*)f->Get("hBkg_BDT");
  TH1D* hSigBDT1 = (TH1D*)f->Get("hSig_BDT1");
  TH1D* hBkgBDT1 = (TH1D*)f->Get("hBkg_BDT1");


  // Create canvas and use implicitly associated
  // histogram to set min/max values and set axis labels.
  TCanvas* c = new TCanvas("c", "Canvas 1", 10, 10, 600, 600);

  hSig->SetNdivisions(505, "x");
  hSig->SetNdivisions(505, "y");
  hSig->SetXTitle("t");
  hSig->SetYTitle("N");
  hSig->SetTitle("TMVA Segnale e Fondo");
  hSig->SetFillColor(18);
  hSig->SetLineStyle(1);
  hSig->SetLineWidth(3);
  hSig->SetLineColor(kBlue);
  hBkg->SetLineStyle(2);
  hBkg->SetLineWidth(3);
  hBkg->SetLineColor(kRed);
  TAxis* xa = hSig->GetXaxis();
  TAxis* ya = hSig->GetYaxis();
  xa->SetTitleOffset(1.2);    //  factor multiplies default offset
  ya->SetTitleOffset(1.6);


  double maxSig = hSig->GetMaximum();
  double maxBkg = hBkg->GetMaximum();
  double maxVal = std::max(maxSig, maxBkg) * 1.4;
  hSig->SetMaximum(maxVal);
  double xMin = -4.;                 // set as appropriate
  double xMax = 4.;
  int binLo = hSig->FindBin(xMin);
  int binHi = hSig->FindBin(xMax);
  hSig->GetXaxis()->SetRange(binLo, binHi);
  hSig->DrawCopy();
  hBkg->DrawCopy("same");

  TLegend* leg = new TLegend(0.2, 0.72, 0.6, 0.88); // x1, y1, x2, y2
  leg->SetTextSize(0.04);
  leg->SetTextFont(42);
  leg->SetBorderSize(0);
  leg->SetFillColor(0);
  leg->AddEntry(hSig, "  signal", "l");
  leg->AddEntry(hBkg, "  background", "l");
  leg->Draw();


  TCanvas* c1 = new TCanvas("c1", "Canvas 2", 10, 10, 600, 600);

  hSigMvp->SetNdivisions(505, "x");
  hSigMvp->SetNdivisions(505, "y");
  hSigMvp->SetXTitle("t");
  hSigMvp->SetYTitle("N");
  hSigMvp->SetTitle("MLP Segnale e Fondo");
  hSigMvp->SetLineStyle(1);
  hSigMvp->SetLineWidth(3);
  hSigMvp->SetFillColor(18);
  hSigMvp->SetLineColor(kBlue);
  hBkgMvp->SetLineStyle(2);
  hBkgMvp->SetLineWidth(3);
  hBkgMvp->SetLineColor(kRed);
  TAxis* xa1 = hSigMvp->GetXaxis();
  TAxis* ya1 = hSigMvp->GetYaxis();
  xa1->SetTitleOffset(1.2);    //  factor multiplies default offset
  ya1->SetTitleOffset(1.6);


  double maxSigMvp = hSigMvp->GetMaximum();
  double maxBkgMvp = hBkgMvp->GetMaximum();
  double maxValMvp = std::max(maxSigMvp, maxBkgMvp) * 1.4;
  hSigMvp->SetMaximum(maxValMvp);
  double xMinMvp = -4.;                 // set as appropriate
  double xMaxMvp = 4.;
  int binLoMvp = hSigMvp->FindBin(xMinMvp);
  int binHiMvp = hSigMvp->FindBin(xMaxMvp);
  hSigMvp->GetXaxis()->SetRange(binLoMvp, binHiMvp);
  hSigMvp->DrawCopy();
  hBkgMvp->DrawCopy("same");

  TLegend* leg1 = new TLegend(0.2, 0.72, 0.6, 0.88); // x1, y1, x2, y2
  leg1->SetTextSize(0.04);
  leg1->SetTextFont(42);
  leg1->SetBorderSize(0);
  leg1->SetFillColor(0);
  leg1->AddEntry(hSigMvp, "  signalMvp", "l");
  leg1->AddEntry(hBkgMvp, "  backgroundMvp", "l");
  leg1->Draw();


  TCanvas* c2 = new TCanvas("c2", "Canvas 3", 10, 10, 600, 600);

  hSigBDT->SetNdivisions(505, "x");
  hSigBDT->SetNdivisions(505, "y");
  hSigBDT->SetXTitle("t");
  hSigBDT->SetYTitle("N");
  hSigBDT->SetFillColor(18);
  hSigBDT->SetTitle("TEST BDT Segnale e fondo");
  hSigBDT->SetLineStyle(1);
  hSigBDT->SetLineWidth(3);
  hSigBDT->SetLineColor(kBlue);
  hBkgBDT->SetLineStyle(2);
  hBkgBDT->SetLineWidth(3);
  hBkgBDT->SetLineColor(kRed);
  TAxis* xa2 = hSigBDT->GetXaxis();
  TAxis* ya2 = hSigBDT->GetYaxis();
  xa2->SetTitleOffset(1.2);    //  factor multiplies default offset
  ya2->SetTitleOffset(1.6);


  double maxSigBDT = hSigBDT->GetMaximum();
  double maxBkgBDT = hBkgBDT->GetMaximum();
  double maxValBDT = std::max(maxSigBDT, maxBkgBDT) * 1.4;
  hSigBDT->SetMaximum(maxValBDT);
  double xMinBDT = -4.;                 // set as appropriate
  double xMaxBDT = 4.;
  int binLoBDT = hSigBDT->FindBin(xMinBDT);
  int binHiBDT = hSigBDT->FindBin(xMaxBDT);
  hSigBDT->GetXaxis()->SetRange(binLoBDT, binHiBDT);
  hSigBDT->DrawCopy();
  hBkgBDT->DrawCopy("same");

  TLegend* leg2 = new TLegend(0.2, 0.72, 0.6, 0.88); // x1, y1, x2, y2
  leg2->SetTextSize(0.04);
  leg2->SetTextFont(42);
  leg2->SetBorderSize(0);
  leg2->SetFillColor(0);
  leg2->AddEntry(hSigBDT, "  signalBDT", "l");
  leg2->AddEntry(hBkgBDT, "  backgroundBDT", "l");
  leg2->Draw();



TCanvas* c3 = new TCanvas("c3", "Canvas 4", 10, 10, 600, 600);

hSigBDT1->SetAxisRange(0,1000,"Y");

hSigBDT1->SetNdivisions(505, "x");
hSigBDT1->SetNdivisions(505, "y");
hSigBDT1->SetXTitle("t");
hSigBDT1->SetYTitle("N");
hSigBDT1->SetTitle("Training BDT Segnale e fondo");
hSigBDT1->SetLineStyle(1);
hSigBDT1->SetLineWidth(3);
hSigBDT1->SetFillColor(18);
hSigBDT1->SetLineColor(kBlue);
hBkgBDT1->SetLineStyle(2);
hBkgBDT1->SetLineWidth(3);
hBkgBDT1->SetLineColor(kRed);


  hSigBDT1->Draw();
  hBkgBDT1->Draw("same");


  TLegend* leg3 = new TLegend(0.2, 0.72, 0.4, 0.88); // x1, y1, x2, y2
  leg3->SetTextSize(0.04);
  leg3->SetTextFont(42);
  leg3->SetBorderSize(0);
  leg3->SetFillColor(0);
  leg3->AddEntry(hSigBDT, "  signalBDT", "l");
  leg3->AddEntry(hBkgBDT, "  backgroundBDT", "l");
  leg3->Draw();

  TGraph* func_sig = (TGraph*)f->Get("funcsig");
  TGraph* func_bkg = (TGraph*)f->Get("funcbkg");
  TCanvas* mygraph = new TCanvas("mygraph", "mygraph4");
    func_sig->Draw("AL*");
    func_bkg->Draw("same");

}
